const notiDummyData = [
    {
      username: 'Zephyr',
      imageUrl: 'https://s3.amazonaws.com/filestore.rescuegroups.org/5880/pictures/animals/12201/12201353/53939364_500x500.jpg',
      text: 'Junior Mousecatcher at The Whiskers Foundation',
    },
    {
      username: 'Pickle',
      imageUrl: 'https://iheartcats.com/wp-content/uploads/2015/12/shutterstock_171850070.jpg',
      text: 'Senior Napper at Catnip Industries Worldwide'
    }
  ];
  
  export default notiDummyData;