import React, { Component } from 'react';
import UserProfile from './profiledetails/profiledetail';


class Profile extends Component {


  render() {
    return (
      <div className="App">
        <UserProfile/>
      </div>
    );
  }
}
export default Profile;