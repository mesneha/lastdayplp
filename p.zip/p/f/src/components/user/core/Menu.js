import React from "react";
import { Link } from "react-router-dom";
import MainHome from '../core/MainHome';

export const Menu = () => {
  return (
    <div>
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className="container-fluid">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
            <img
              src={require("../assets/images/img.jpg")}
              width="100px"
              height="40px"
            />
          </Link>
        </div>
        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav ">
            <li className="active" />
          </ul>
          <ul className="nav navbar-nav navbar-right">
            <br />
            <li>
              <Link to="/Signup">
              <span class="glyphicon glyphicon-user"></span>&nbsp;User
              </Link>
            </li>
            <li>
              <Link to="/register"><span class="glyphicon glyphicon-home"></span>&nbsp;Organization
              </Link>
            </li>
            <li>
              <Link to="/Login">
              <span class="glyphicon glyphicon-log-in"></span>&nbsp;Login User
              </Link>
            </li>
            <li>
              <Link to="/LoginOrg" >
              <span class="glyphicon glyphicon-log-in"></span>&nbsp;Login Organization
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <MainHome/>
    </div>
  );
};

export default Menu;
