import React, { Component } from 'react'

import NavComponent from '../navcomponent';

export class Home extends Component {
  render() {
    return (
      <div>
           <NavComponent/>
          <h1>YOU JOIN</h1>
         
          
      </div>
    )
  }
}

export default Home
